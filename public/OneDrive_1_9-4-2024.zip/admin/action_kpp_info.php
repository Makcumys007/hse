<?php 
    
    include 'connection.php';

    function get_data(string $atribut) {
            if (isset($_POST[$atribut])) {
            return $_POST[$atribut];        
        } return 0;
    }


    session_start();

    if($_SESSION['login_user']) { 

        $days_no_lti = get_data("days_no_lti");
        $count_lti_this_year = get_data("count_lti_this_year");
        $last_lti = get_data("last_lti");
        

        mysqli_query($connection, "INSERT INTO `hse_board`.`kpp_info`(`days_no_lti`,`count_lti_this_year`,`last_lti`)
        VALUES ('$days_no_lti','$count_lti_this_year','$last_lti');");

            header("Location: index.php?update=true");

    
    } else {
            header("Location: login.php?log_in=false");
        }
?>