<?php 
    
    include 'connection.php';

    function get_data(string $atribut) {
            if (isset($_POST[$atribut])) {
            return $_POST[$atribut];        
        } return 0;
    }


    session_start();

    if($_SESSION['login_user']) { 

        $string = get_data("string");

        mysqli_query($connection, "INSERT INTO `hse_board`.`kpp_run_string`(`string`)
        VALUES ('$string');");

            header("Location: index.php?update=true");

    
    } else {
            header("Location: login.php?log_in=false");
        }
?>