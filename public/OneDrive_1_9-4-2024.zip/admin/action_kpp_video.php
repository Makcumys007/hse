<?php 
    
    include 'connection.php';

    function generateRandomString($length = 15) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
    return $randomString;
}

    function uploadFile(string $value) {
        $link = "";
        if ($_FILES && $_FILES[$value]["error"]== UPLOAD_ERR_OK)
            {
                $name = $_FILES[$value]["name"];
                $ext = pathinfo($name, PATHINFO_EXTENSION);
                $name = "kpp_".generateRandomString(10);
                $link = "res/".$name.".".$ext;

                move_uploaded_file($_FILES[$value]["tmp_name"], "../res/".$name.".".$ext);
                echo "Файл загружен";
            } else {
                $link = "null";
            }            
        return trim($link);
    }


   session_start();

    if($_SESSION['login_user']) { 

       $file = uploadFile("video");
       
       mysqli_query($connection, "

    INSERT INTO `kpp_video`(`url`)
    VALUES
    (
    '$file');


    ");

       header("Location: index.php?upload=true");

       } else {
        header("Location: login.php?log_in=false");
    }


   
   
?>



   
     
   

    
    


