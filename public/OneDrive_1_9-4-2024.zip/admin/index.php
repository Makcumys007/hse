<?php 
    
    include 'connection.php';
session_start();

    if($_SESSION['login_user']) {

       $result = mysqli_query($connection, "SELECT * FROM hse_info ORDER BY id DESC LIMIT 1;");
       $item = mysqli_fetch_array($result);
       $lti = $item['lti'];
       $mtc = $item['mtc'];
       $fac = $item['fac'];
       $lti_fi = $item['lti_fi'];
       $smf = $item['smf'];

echo "<!DOCTYPE html>
<html>


<head>
    <meta charset=\"utf-8\" />
    <!--[if lt IE 9]><script src=\"http://html5shiv.googlecode.com/svn/trunk/html5.js\"></script><![endif]-->
    
    <title>Обновление HSE Board</title>

    <script type=\"text/javascript\">
                var href = document.location.href;
                if(href.includes(\"update=true\")) {
                    alert('Информация обновлена!');
                }   

                var href = document.location.href;
                if(href.includes(\"upload=true\")) {
                    alert('Файлы загружены!');
                }   

            </script>
    
    <meta name=\"keywords\" content=\" \"/>
    <meta name=\"description\" content=\" \"/>

    
    <link href=\"../styles/reset.css\" rel=\"stylesheet\">
    <link href=\"../styles/styles.css\" rel=\"stylesheet\">
    
</head>

<body>
<br>
<br>
<br>
<div id=\"wrapper\">

<a href=\"update.php\">Обновить HSE Board</a>
<br><br>
<a href=\"update_kpp.php\">Обновить KPP Board</a>

</div>


</body>
</html>
";
    } else {
        header("Location: login.php?log_in=false");
    }


   
   
?>

