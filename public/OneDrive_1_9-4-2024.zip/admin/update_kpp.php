<?php 
    
    include 'connection.php';
session_start();

    if($_SESSION['login_user']) {

       $result = mysqli_query($connection, "SELECT * FROM kpp_info ORDER BY id DESC LIMIT 1;");
       $item = mysqli_fetch_array($result);
       $days_no_lti = $item['days_no_lti'];
       $count_lti_this_year = $item['count_lti_this_year'];
       $last_lti = $item['last_lti'];

       $result = mysqli_query($connection, "SELECT * FROM kpp_run_string ORDER BY id DESC LIMIT 1;");
       $item = mysqli_fetch_array($result);
       $string = $item['string'];
      

echo "<!DOCTYPE html>
<html>


<head>
    <meta charset=\"utf-8\" />
    <!--[if lt IE 9]><script src=\"http://html5shiv.googlecode.com/svn/trunk/html5.js\"></script><![endif]-->
    
    <title>Обновление KPP Board</title>

    <script type=\"text/javascript\">
                var href = document.location.href;
                if(href.includes(\"update=true\")) {
                    alert('Информация обновлена!');
                }   

                var href = document.location.href;
                if(href.includes(\"upload=true\")) {
                    alert('Файлы загружены!');
                }   

            </script>
    
    <meta name=\"keywords\" content=\" \"/>
    <meta name=\"description\" content=\" \"/>

    
    <link href=\"../styles/reset.css\" rel=\"stylesheet\">
    <link href=\"../styles/styles.css\" rel=\"stylesheet\">
    
</head>

<body>
<div id=\"wrapper\">

     <img src=\"../images/example2.png\" style=\"width: 25%;\" \>
    <p> Сегодня: ".date("d.m.Y") ."</p>
    <form action=\"action_kpp_info.php\" method=\"post\">
        <label>КОЛИЧЕСТВО ДНЕЙ БЕЗ ТРАВМ</label>
        <br>
        <input type=\"number\" name=\"days_no_lti\" value=\"". $days_no_lti ."\" \>
        <br>
        <label>КОЛИЧЕСТВО НЕСЧАСТНЫХ СЛУЧАЕВ В ЭТОМ ГОДУ</label>
        <br>
        <input type=\"number\" name=\"count_lti_this_year\" value=\"". $count_lti_this_year ."\" \>
        <br>
        <label>ДАТА ПОСЛЕДНЕГО НЕСЧАТНОГО СЛУЧАЯ</label>
        <br>
        <input type=\"date\" name=\"last_lti\" value=\"". $last_lti ."\" \>
        
        <br><br>
        <input type=\"submit\" value=\"Обновить\">
    </form>
    <br>
   
    <form action=\"action_kpp_video.php\" method=\"post\" enctype=\"multipart/form-data\">

        <label>Обновить видео</label>
        <br>
        <input type=\"file\" name=\"video\" >
        <br>
        <br>
        <input type=\"submit\" value=\"Загрузить\">         
    </form>
    <br>

    <form action=\"action_kpp_string.php\" method=\"post\" >

        <label>БЕГУЩАЯ СТРОКА</label>
        <br>
        <textarea name=\"string\" rows=\"4\" cols=\"50\">".$string."
</textarea>
        <br>
        <input type=\"submit\" value=\"Загрузить\">     
        <br>    
        <br>    
    </form>
    <br>
    

</div>


</body>
</html>
";
    } else {
        header("Location: login.php?log_in=false");
    }


   
   
?>